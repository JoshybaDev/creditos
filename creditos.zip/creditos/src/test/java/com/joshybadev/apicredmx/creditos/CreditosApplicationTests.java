package com.joshybadev.apicredmx.creditos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CreditosApplicationTests {

	@Test
	void contextLoads() {
	}

}
